from django.shortcuts import render, redirect
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.contrib.auth import authenticate, login, logout
from .serializers import UsersSerializer,EmployeeTaskSerializer
from .models import Users, EmployeeTask
from rest_framework import status
# Create your views here.
@api_view(['GET','POST'])
def home(request):
    return render(request, 'login.html')

@api_view(['GET','POST'])
def login_view(request):
    if request.method == 'POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        try:
            check=Users.objects.get(Email=email, Password=password)
            serializer = UsersSerializer(check)
            request.session['email']=serializer.data['Email']
            request.session['role']=serializer.data['Role']
            request.session['name']=serializer.data['Name']
            request.session['id']=serializer.data['Id']
            return JsonResponse({'exists':  True})
        except Users.DoesNotExist:
            return JsonResponse({'exists': False})
        except Exception as e:
            return JsonResponse( {'exists': 'error'})


  
@api_view(['GET','POST'])
def signup(request):       
    return render(request, 'signup.html')
  
@api_view(['GET','POST'])
def createUser(request):
    if request.method == 'POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        name=request.POST.get('name')
        role=request.POST.get('role')        
        try:
            check=Users.objects.get(Email=email,Role=role)
            if check is not None:
                return JsonResponse( {'exists': False})
        except Users.DoesNotExist:
            createUser=Users(Email=email,Name=name,Password=password,Role=role)
            createUser.save()
            return JsonResponse({'exists': True})
        except Exception as e:
            return JsonResponse({'exists': 'error'})

@api_view(['GET','POST'])
def dashboard(request):
    try:
        if request.session['name']=='':
            return render(request, 'login.html')
        else:
            return render(request, 'dashboard.html',{'role':request.session['role'],'name':request.session['name'],'id':request.session['id']})
    except:
        return render(request, 'login.html')


@api_view(['GET','POST'])
def getTasks(request):
    try:
        role=request.session['role']
        id=request.session['id']
        if role=='Admin':
            data=EmployeeTask.objects.all()
            serializer=EmployeeTaskSerializer(data, many=True)
            return JsonResponse(serializer.data, safe=False)
        elif role=='Employee':
            data=EmployeeTask.objects.filter(EmployeeId=id)
            serializer=EmployeeTaskSerializer(data, many=True)
            return JsonResponse(serializer.data, safe=False)
        
    except Exception as e:
        return JsonResponse({'status': 'error'})
    
@api_view(['GET','POST'])
def markComplete(request):
    try:
        if request.method == 'POST':
            id=request.POST.get('id')
            task=request.POST.get('task')
            employee_task=EmployeeTask.objects.get(EmployeeId=id,Task=task, Status='Pending')
            employee_task.Status='Completed'
            employee_task.save()
            data=EmployeeTask.objects.filter(EmployeeId=id)
            serializer=EmployeeTaskSerializer(data, many=True)
            return JsonResponse(serializer.data, safe=False)
    except Exception as e:
        return JsonResponse({'status': 'error'})
    

@api_view(['GET','POST'])
def createTask(request):
    try:
        if request.method == 'POST':
            name=request.POST.get('name')
            task=request.POST.get('task')
            action=request.POST.get('action')
            if action=='Create':
                user=Users.objects.get(Name=name)
                employee_task=EmployeeTask(EmployeeId=user.Id,Name=name,Task=task, Status='Pending')
                employee_task.save()
            elif action=='Update':
                Id=request.POST.get('id')
                employeeid=request.POST.get('employeeid')
                oldtask=request.POST.get('oldtask')
                employee_task=EmployeeTask.objects.get(Id=Id,EmployeeId=employeeid,Task=oldtask, Status='Pending')
                employee_task.Task=task
                employee_task.save()
            data=EmployeeTask.objects.all()
            serializer=EmployeeTaskSerializer(data, many=True)
            return JsonResponse(serializer.data, safe=False)
    except Exception as e:
        return JsonResponse({'status': 'error'})
    
@api_view(['GET','POST'])
def logout(request):
    try:
        request.session['email']=''
        request.session['role']=''
        request.session['name']=''
        request.session['id']=''
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': 'error'})