from django.db import models

# Create your models here.
class Users(models.Model):
    Id = models.AutoField(primary_key=True, editable=False)
    Email=models.CharField(max_length=100)
    Password=models.CharField(max_length=50)
    Role=models.CharField(max_length=20)
    Name=models.CharField(max_length=50)

class EmployeeTask(models.Model):
    Id = models.AutoField(primary_key=True, editable=False)
    EmployeeId=models.CharField(max_length=100)
    Name=models.CharField(max_length=50)
    Task=models.CharField(max_length=1000)
    Status=models.CharField(max_length=50)

