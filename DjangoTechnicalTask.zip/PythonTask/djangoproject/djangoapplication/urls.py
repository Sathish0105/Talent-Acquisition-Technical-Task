
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.home, name='home'),
    path('login', views.login_view, name='login'),
    path('createUser', views.createUser, name='createUser'),
    path('signup', views.signup, name='signup'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('getTasks', views.getTasks, name='getTasks'),
    path('markComplete', views.markComplete, name='markComplete'),
    path('createTask', views.createTask, name='createTask'),
    path('logout', views.logout, name='logout'),
]
